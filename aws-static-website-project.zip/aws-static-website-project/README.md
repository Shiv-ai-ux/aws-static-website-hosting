# Static Website Hosting on AWS using Amazon S3

**Student:** S Shiv Netra  
**Register Number:** 44110778  
**Guide:** Ms. R. Sasirek

## Project overview
This is a static website built using HTML and CSS. Store the source code in GitHub and host the website using Amazon S3 static website hosting.

## Files
- `index.html` — website content and page structure
- `style.css` — styling and responsive layout

## Run locally
1. Extract this folder.
2. Double-click `index.html` to open it in a browser.

## AWS hosting outline
1. Create an S3 bucket in your chosen AWS Region.
2. Upload `index.html` and `style.css`.
3. Configure static website hosting and set `index.html` as the index document.
4. Follow AWS's current permissions guidance before making the website public.
5. Test the S3 website endpoint.

## Important
The basic S3 website endpoint supports HTTP, not HTTPS. CloudFront can be added for HTTPS. Route 53 and a custom domain are optional for the basic project.

## Learning objectives
- Understand static websites and cloud hosting.
- Use Amazon S3 to store and serve website files.
- Use GitHub to share project source code.
- Understand the purpose of DNS and Route 53.
